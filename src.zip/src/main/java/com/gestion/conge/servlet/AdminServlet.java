package com.gestion.conge.servlet;

import com.gestion.conge.dao.UtilisateurDAO; // Vous devez avoir ce DAO
import com.gestion.conge.model.Utilisateur;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.util.List;

@WebServlet("/admin/dashboard")
public class AdminServlet extends HttpServlet {

    private UtilisateurDAO utilisateurDAO = new UtilisateurDAO(); // Assurez-vous d'avoir ce DAO

    /**
     * Gère l'affichage (soit la liste, soit le formulaire de modification).
     */
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String action = req.getParameter("action");

        if ("modifier".equals(action)) {
            // --- AFFICHER LE FORMULAIRE DE MODIFICATION ---
            try {
                Integer id = Integer.valueOf(req.getParameter("id"));
                Utilisateur u = utilisateurDAO.findById(id);
                if (u != null) {
                    req.setAttribute("utilisateur", u);
                    req.getRequestDispatcher("/admin/modifierUtilisateur.jsp").forward(req, resp);
                } else {
                    resp.sendRedirect(req.getContextPath() + "/admin/dashboard");
                }
            } catch (Exception e) {
                e.printStackTrace();
                resp.sendRedirect(req.getContextPath() + "/admin/dashboard");
            }
        } else {
            // --- AFFICHER LA LISTE (COMPORTEMENT PAR DÉFAUT) ---
            List<Utilisateur> users = utilisateurDAO.findAll();
            req.setAttribute("users", users);
            req.getRequestDispatcher("/admin/dashboard.jsp").forward(req, resp);
        }
    }

    /**
     * Gère les actions : Créer, Supprimer, Sauvegarder (Modifier).
     */
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String action = req.getParameter("action");
        if (action == null) {
            resp.sendRedirect(req.getContextPath() + "/admin/dashboard");
            return;
        }

        try {
            if ("creer".equals(action)) {
                // --- LOGIQUE DE CRÉATION ---
                String prenom = req.getParameter("prenom");
                String nom = req.getParameter("nom");
                String email = req.getParameter("email");
                String motDePasse = req.getParameter("password"); // !! Pensez à HACHER le mot de passe
                String role = req.getParameter("role");

                Utilisateur newUser = new Utilisateur(nom, prenom, email, motDePasse, role);
                utilisateurDAO.save(newUser);

            } else if ("supprimer".equals(action)) {
                // --- LOGIQUE DE SUPPRESSION ---
                Integer id = Integer.valueOf(req.getParameter("id"));
                Utilisateur u = utilisateurDAO.findById(id);
                if (u != null) {
                    utilisateurDAO.delete(u);
                }

            } else if ("sauvegarder".equals(action)) {
                // --- LOGIQUE DE MODIFICATION (SAUVEGARDE) ---
                Integer id = Integer.valueOf(req.getParameter("id"));
                Utilisateur u = utilisateurDAO.findById(id);

                if (u != null) {
                    u.setPrenom(req.getParameter("prenom"));
                    u.setNom(req.getParameter("nom"));
                    u.setEmail(req.getParameter("email"));
                    u.setRole(req.getParameter("role"));

                    // Ne changer le mot de passe que s'il est fourni
                    String mdp = req.getParameter("password");
                    if (mdp != null && !mdp.isEmpty()) {
                        // !! Pensez à HACHER le mot de passe
                        u.setMotDePasse(mdp);
                    }
                    utilisateurDAO.save(u); // "save" fait la mise à jour
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            // Gérer les erreurs (ex: email déjà pris)
        }

        // Après toute action POST, rediriger vers le dashboard
        resp.sendRedirect(req.getContextPath() + "/admin/dashboard");
    }
}