package com.gestion.conge.servlet;

import com.gestion.conge.dao.DemandeCongeDAO;
import com.gestion.conge.model.DemandeConge;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;
import java.io.IOException;
import java.util.List;

@WebServlet("/manager/dashboard")
public class ManagerServlet extends HttpServlet {
    private DemandeCongeDAO demandeDAO = new DemandeCongeDAO();

    /**
     * N'affiche que les demandes qui nécessitent une action (EN_ATTENTE).
     */
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

        // <-- MODIFICATION IMPORTANTE
        // On ne charge que les demandes "EN_ATTENTE" pour le tableau de bord
        List<DemandeConge> demandes = demandeDAO.findByStatut("EN_ATTENTE");

        req.setAttribute("demandes", demandes);

        // <-- MODIFICATION IMPORTANTE
        // Correction du chemin vers votre JSP
        req.getRequestDispatcher("/manager/dashboard.jsp").forward(req, resp);
    }

    /**
     * Traite l'action (accepter/refuser) et met à jour le statut.
     */
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        try {
            String action = req.getParameter("action");
            Integer id = Integer.valueOf(req.getParameter("id"));
            DemandeConge d = demandeDAO.findById(id);

            if (d != null) {
                if ("accepter".equals(action)) {
                    d.setStatut("ACCEPTEE");
                } else if ("refuser".equals(action)) {
                    d.setStatut("REFUSEE");
                }
                demandeDAO.save(d); // 'save' doit gérer la mise à jour (merge/update)
            }
        } catch (Exception e) {
            e.printStackTrace();
            // Idéalement, ajouter un message d'erreur pour l'utilisateur
        }

        // On redirige vers le doGet. Le doGet rechargera la liste (sans la demande
        // qui vient d'être traitée), ce qui la fera "disparaître".
        resp.sendRedirect(req.getContextPath() + "/manager/dashboard");
    }
}