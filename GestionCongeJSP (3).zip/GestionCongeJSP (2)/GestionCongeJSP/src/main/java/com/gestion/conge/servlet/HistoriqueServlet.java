package com.gestion.conge.servlet;

import com.gestion.conge.dao.DemandeCongeDAO;
import com.gestion.conge.model.DemandeConge;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

@WebServlet("/manager/historique")
public class HistoriqueServlet extends HttpServlet {
    private DemandeCongeDAO demandeDAO = new DemandeCongeDAO();

    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

        String termeRecherche = req.getParameter("recherche");
        List<DemandeConge> demandesHistorique;

        // <-- LOGIQUE DE RECHERCHE PAR CORRESPONDANCE EXACTE -->
        if (termeRecherche != null && !termeRecherche.trim().isEmpty()) {

            // On divise l'entrée par les espaces
            String[] noms = termeRecherche.trim().split("\\s+");

            if (noms.length == 1) {
                // Si 1 seul mot est tapé, on cherche une correspondance exacte
                // sur le nom OU le prénom.
                demandesHistorique = demandeDAO.findProcessedByExactSingleName(noms[0]);

            } else if (noms.length >= 2) {
                // Si 2 mots ou plus, on cherche une correspondance exacte
                // sur (nom ET prénom) ou (prénom ET nom).
                // On ne prend que les 2 premiers mots.
                demandesHistorique = demandeDAO.findProcessedByExactFullName(noms[0], noms[1]);

            } else {
                // Ne devrait pas arriver, mais sécurité
                demandesHistorique = Collections.emptyList();
            }

        } else {
            // Comportement normal : charger tout l'historique
            List<DemandeConge> acceptees = demandeDAO.findByStatut("ACCEPTEE");
            List<DemandeConge> refusees = demandeDAO.findByStatut("REFUSEE");

            demandesHistorique = new ArrayList<>(acceptees);
            demandesHistorique.addAll(refusees);
        }

        req.setAttribute("demandesHistorique", demandesHistorique);
        req.getRequestDispatcher("/manager/historique.jsp").forward(req, resp);
    }
}